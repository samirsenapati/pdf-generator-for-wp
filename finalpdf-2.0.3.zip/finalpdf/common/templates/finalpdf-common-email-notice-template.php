<?php
/**
 * Provide a common view for the plugin
 *
 * This file is used to markup the common aspects of the plugin.
 *
 * @link       https://finaldoc.io/
 * @since      1.0.0
 *
 * @package    FinalPDF
 * @subpackage FinalPDF/common/partials
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}
?>
<span style="<?php echo esc_attr( $color ); ?>"><?php echo esc_html( $message ); ?></span>

