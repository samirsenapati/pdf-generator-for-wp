<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://finaldoc.io/
 * @since      1.0.0
 *
 * @package    FinalPDF
 * @subpackage FinalPDF/admin
 */

// silence is golden.
